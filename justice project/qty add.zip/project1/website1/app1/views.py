from django.shortcuts import render
from django.http import HttpResponse
from django. http import HttpResponseRedirect
from django.template import loader
from .models import Contact
from.models import Registration
from.models import Products
from.models import Cart





# Create your views here.
def index(request):
    Template=loader.get_template("index.html")
    return HttpResponse(Template.render({},request))

def about(request):
    Template=loader.get_template("about.html")
    return HttpResponse(Template.render({},request))

def products(request):
    pro=Products.objects.all().values()
    context={
        'pro': pro
    }
    Template=loader.get_template("products.html")
    return HttpResponse(Template.render(context,request))

def services(request):
    Template=loader.get_template("services.html")
    return HttpResponse(Template.render({},request))



def contact(request):
    if request.method == 'POST':
        cname=request.POST['contact_name']
        cemail=request.POST['contact_email']
        cmessage=request.POST['contact_msg']

        con= Contact(con_name=cname, con_email=cemail, con_message=cmessage)
        con.save()

    Template=loader.get_template("contact.html")
    return HttpResponse(Template.render({},request))

def registration(request):
    if "user" in request.session:
        return HttpResponseRedirect("/account")
    if request.method == 'POST':
        rname=request.POST['reg_name']
        remail=request.POST['reg_email']
        rusername=request.POST['reg_username']
        rpassword=request.POST['reg_password']
        rphonenumber=request.POST['reg_phonenumber']

        x= Registration(reg_name=rname,reg_email=remail,reg_username=rusername,reg_password=rpassword,reg_phonenumber=rphonenumber)
        x.save()

    template=loader.get_template("registration.html")
    return HttpResponse(template.render({},request))

def login(request):
    if "user" in request.session:
        return HttpResponseRedirect("/account")
    if request.method == 'POST':
        log_user= request.POST['log_username']
        log_pswd=request.POST['log_password']


        log = Registration.objects.filter(reg_username=log_user,reg_password=log_pswd)
        if log:
            request.session["user"]=log_user
            return HttpResponseRedirect("/account")

    template=loader.get_template("login.html")
    return HttpResponse(template.render({},request))

def account(request):
    if "user" not in request.session:
        return HttpResponseRedirect("/login")
    template=loader.get_template("account.html")
    return HttpResponse(template.render({},request))

def logout(request):
    if "user" in request.session:
        del request.session["user"]
    return HttpResponseRedirect("/login")

# dashboard

def dashboard(request):
    template=loader.get_template("dashboard/dashboard.html")
    return HttpResponse(template.render({},request))

def contacts(request):
    cons=Contact.objects.all().values()
    context= {
        'contacts' : cons
    }
    template=loader.get_template("dashboard/contacts.html")
    return HttpResponse(template.render(context,request))

def registrationadmin(request):
    regadmin=Registration.objects.all().values()
    context={
        'registrationadmin' : regadmin
    }

    template=loader.get_template("dashboard/registrationadmin.html")
    return HttpResponse(template.render(context,request))

# product page 

def addproduct(request):
    if request.method == 'POST':
        x=request.POST['pro_name']
        y=request.POST['pro_price']
        z=request.FILES['pro_image']

        product = Products(
            pro_name=x,pro_price=y,pro_image=z)
        product.save()
        
    template=loader.get_template("dashboard/addproduct.html")
    return HttpResponse(template.render({},request))

def addtocart(request,id):
    if 'user' not in request.session:
        return HttpResponseRedirect("/login")
        
    exist = Cart.objects.filter(cart_proid =id,cart_user= request.session["user"])
    if exist:
        existcart=Cart.objects.filter(cart_proid=id,cart_user=request.session["user"])[0]
        existcart.cart_qty +=1
        existcart.cart_amount = existcart.cart_qty * existcart.cart_price
        existcart.save()
    else:
        pro = Products.objects.filter(id=id)[0]
        
        cart= Cart(cart_user = request.session["user"],
                   cart_proid = pro.id,
                   cart_name = pro.pro_name,
                   cart_price = pro.pro_price,
                   cart_image = pro.pro_image,
                   cart_qty = 1,
                   cart_amount = pro.pro_price)
        
        cart.save()
    return HttpResponseRedirect("/cart")

def cart(request):
    if "user" not in request.session:
        return HttpResponseRedirect("/login")
    
    # delete cart item

    if 'del' in request.GET:
        id = request.GET['del']
        delcart = Cart.objects.filter(id=id)[0]
        delcart.delete()

    # change cart quantity

    if 'q' in request.GET:
        q = request.GET['q']
        cp = request.GET['cp'] 
        cart3 = Cart.objects.filter(id=cp)[0]  

        if q =='inc':
            cart3.cart_qty+=1
        elif q =='dec':
            if(cart3.cart_qty>1):
                cart3.cart_qty-=1
                cart3.cart_amount = cart3.cart_qty * cart3.cart_price
                cart3.save()


    user = request.session["user"]
    cart=Cart.objects.filter(cart_user=user).values()
    cart2=Cart.objects.filter(cart_user=user)

    tot=0
    for x in cart2:
        tot+=x.cart_amount

    shp = tot * 10/100
    gst = tot * 18/100

    gtot = tot+shp+gst

    context={
        'cart': cart,
        'tot' : tot,
        'shp' : shp,
        'gst' : gst,
        'gtot' : gtot
    }
    template = loader.get_template("cart.html")
    return HttpResponse(template.render(context,request)) 















