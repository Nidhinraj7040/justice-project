from django.db import models

# Create your models here.
class Contact(models.Model):

 con_name=models.CharField(max_length=255)
 con_email=models.CharField(max_length=255)
 con_message=models.TextField()
    
 def __str__(self):
    return self.con_name

class Registration(models.Model):
      reg_name=models.CharField(max_length=255)
      reg_email=models.CharField(max_length=255)
      reg_username=models.CharField(max_length=255)
      reg_password=models.CharField(max_length=255)
      reg_phonenumber=models.CharField(max_length=255)

      def __str__(self):
        return self.reg_name 
      
class Products(models.Model):
 pro_name=models.CharField(max_length=255)
 pro_price=models.CharField(max_length=255)
 pro_image=models.FileField(null=True,upload_to="products")
    
 def __str__(self):
    return self.pro_name
 
class Cart(models.Model):
    cart_user = models.CharField(max_length=250,default=None)
    cart_proid= models.IntegerField(null=True)
    cart_name = models.CharField(max_length=250)
    cart_price = models.FloatField(max_length=250)
    cart_image = models.FileField(null=True)
    cart_qty = models.IntegerField()
    cart_amount= models.FloatField()

    def __str__(self):
       return self.cart_name    
      


  
  