from django.contrib import admin
from.models import Contact
from.models import Registration
from.models import Products
from.models import Cart

# Register your models here.
admin.site.register(Contact)
admin.site.register(Registration)
admin.site.register(Products)
admin.site.register(Cart)